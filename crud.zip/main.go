package main

import (
	"database/sql"
	"fmt"
	"log"
	"strconv"

	"net/http"

	"github.com/labstack/echo/v4"
	_ "github.com/lib/pq"
)

func main() {
	var err error
	//pwd := os.Getenv("DBPASSWORD")
	//fmt.Println("password", pwd)
	db, err := sql.Open("postgres", "user=postgres password=Qaz!12345678 dbname=crud sslmode=disable")
	if err != nil {
		log.Fatal(err)
	}

	if err = db.Ping(); err != nil {
		panic(err)
	} else {
		fmt.Println("DB Connected...")
	}

	e := echo.New()

	type Employee struct {
		Id     int    `json:"id"`
		Name   string `json:"name"`
		Salary int    `json: "salary"`
		Age    int    `json : "age"`
	}
	e.POST("/employee", func(c echo.Context) error {
		u := new(Employee)
		if err := c.Bind(u); err != nil {
			return err
		}
		sqlStatement := "INSERT INTO employee (id,name, salary,age)VALUES ($1, $2, $3,$4)"
		res, err := db.Query(sqlStatement, u.Id, u.Name, u.Salary, u.Age)
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println(res)
			fmt.Println("POST DATA", u)
			return c.JSON(http.StatusCreated, u)
		}
		return c.String(http.StatusOK, "ok")
	})

	e.GET("/employee", func(c echo.Context) error {
		sqlStatement := "SELECT id, name, salary, age FROM employee order by id"
		rows, err := db.Query(sqlStatement)
		if err != nil {
			fmt.Println(err)
		}
		defer rows.Close()
		emplset := make([]Employee, 0)
		fmt.Println("query passed", rows)

		for rows.Next() {
			empl := Employee{}
			err2 := rows.Scan(&empl.Id, &empl.Name, &empl.Salary, &empl.Age)
			//if we get an error
			if err2 != nil {
				return err2
			}
			fmt.Println(empl)
			emplset = append(emplset, empl)
		}
		fmt.Println(emplset)
		return c.JSON(http.StatusCreated, emplset)

	})
	e.PUT("/employee/:id", func(c echo.Context) error {
		u := new(Employee)
		if err := c.Bind(u); err != nil {
			return err
		}
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			return err
		}
		sqlStatement := "UPDATE employee SET name=$1,salary=$2,age=$3 WHERE id=$4"
		res, err := db.Query(sqlStatement, u.Name, u.Salary, u.Age, id)
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println(res)
			return c.JSON(http.StatusCreated, u)
		}

		return c.String(http.StatusOK, "ok")
	})
	e.DELETE("/employee/:id", func(c echo.Context) error {
		id, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			return err
		}
		sqlStatement := "DELETE FROM employee WHERE id=$1 "
		res, err := db.Query(sqlStatement, id)
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println(res)
			return c.JSON(http.StatusOK, "Deleted")
		}
		return c.String(http.StatusOK, "Deleted")
	})

	e.Logger.Fatal(e.Start(":8080"))
}

